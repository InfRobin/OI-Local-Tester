﻿这个 runtime/ 目录是 Python 的便携运行时，仅用于运行 OI 对拍器。
Python 使用 PSF 许可证，详见 PYTHON-LICENSE.txt；Tcl/Tk 的许可证在 tcl/ 目录中。
